const WHATSAPP_NUMBER = "2250778863902";
// EXEMPLES : remplace les noms, prix et descriptions par tes vrais produits.
const products = [
  {id:1,name:"Smartphone Android",category:"Téléphones",price:75000,description:"Exemple de prix — à modifier",emoji:"📱"},
  {id:2,name:"iPhone reconditionné",category:"Téléphones",price:180000,description:"Exemple de prix — à modifier",emoji:"📲"},
  {id:3,name:"Écouteurs sans fil",category:"Accessoires",price:10000,description:"Exemple de prix — à modifier",emoji:"🎧"},
  {id:4,name:"Chargeur rapide",category:"Accessoires",price:7500,description:"Exemple de prix — à modifier",emoji:"🔌"},
  {id:5,name:"Coque de protection",category:"Accessoires",price:3000,description:"Exemple de prix — à modifier",emoji:"🛡️"},
  {id:6,name:"Batterie externe",category:"Accessoires",price:12000,description:"Exemple de prix — à modifier",emoji:"🔋"},
  {id:7,name:"Smartphone grand écran",category:"Téléphones",price:95000,description:"Exemple de prix — à modifier",emoji:"📱"},
  {id:8,name:"Câble USB-C",category:"Accessoires",price:2500,description:"Exemple de prix — à modifier",emoji:"〰️"}
];
let activeCategory = "Tous";
const formatPrice = n => new Intl.NumberFormat("fr-FR").format(n) + " FCFA";
function orderProduct(p){
  const message = `Bonjour tech.ci, je souhaite commander : ${p.name}. Prix affiché : ${formatPrice(p.price)}. Pouvez-vous confirmer la disponibilité et les frais de livraison ?`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank","noopener");
}
function renderProducts(){
  const query = document.getElementById("search").value.trim().toLocaleLowerCase("fr");
  const shown = products.filter(p => (activeCategory==="Tous" || p.category===activeCategory) && (p.name+" "+p.category+" "+p.description).toLocaleLowerCase("fr").includes(query));
  const root = document.getElementById("products");
  if(!shown.length){root.innerHTML='<p>Aucun produit trouvé. Essaie un autre mot.</p>';return;}
  root.innerHTML = shown.map(p => `<article class="product-card">
    <div class="product-art"><span class="category-tag">${p.category}</span><span class="emoji" aria-hidden="true">${p.emoji}</span></div>
    <div class="product-info"><h3>${p.name}</h3><p>${p.description}</p><div class="product-bottom"><span class="price">${formatPrice(p.price)}</span><button class="order-btn" data-order="${p.id}">Commander ↗</button></div></div>
  </article>`).join("");
  root.querySelectorAll("[data-order]").forEach(btn=>btn.addEventListener("click",()=>orderProduct(products.find(p=>p.id===Number(btn.dataset.order)))));
}
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  activeCategory=btn.dataset.category;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===btn));
  renderProducts();
}));
document.getElementById("search").addEventListener("input",renderProducts);
document.getElementById("year").textContent = new Date().getFullYear();
renderProducts();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
